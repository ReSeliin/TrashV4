# cloudup
CloudUP altyapısı, tarafımca yapılıp 18.10.2020 - 20:11'de paylaşılmıştır. Sonrasında paylaşılacak tüm CloudUP bot altyapısına tarafımca kaldırma yetkisine sahipim.
